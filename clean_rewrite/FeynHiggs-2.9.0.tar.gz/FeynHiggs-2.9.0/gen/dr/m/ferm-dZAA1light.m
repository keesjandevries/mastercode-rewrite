-(((-4*Alfa*A0[MT2])/(3*Pi) + (8*Alfa*B0i[bb00, MZ2, MT2, MT2])/(3*Pi) - 
   (4*Alfa*MZ2*B0i[bb1, MZ2, MT2, MT2])/(3*Pi))/MZ2)
