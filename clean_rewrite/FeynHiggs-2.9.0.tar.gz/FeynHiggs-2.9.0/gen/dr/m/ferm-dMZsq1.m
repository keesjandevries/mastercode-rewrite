(3*Alfa*B0i[bb00, MZ2, 0, 0])/(4*CW2*Pi*SW2) - 
 (3*Alfa*MZ2*B0i[bb1, MZ2, 0, 0])/(8*CW2*Pi*SW2) + 
 (-(Alfa*(-4 + SW2^(-1) + 8*SW2)*A0[Mf2[2, Gen3]])/(8*CW2*Pi) - 
   (3*Alfa*(-8/3 + SW2^(-1) + (32*SW2)/9)*A0[Mf2[3, Gen3]])/(8*CW2*Pi) - 
   (3*Alfa*(-4/3 + SW2^(-1) + (8*SW2)/9)*A0[Mf2[4, Gen3]])/(8*CW2*Pi) + 
   (Alfa*(-4 + SW2^(-1) + 8*SW2)*B0i[bb00, MZ2, Mf2[2, Gen3], Mf2[2, Gen3]])/
    (4*CW2*Pi) + (3*Alfa*(-8/3 + SW2^(-1) + (32*SW2)/9)*
     B0i[bb00, MZ2, Mf2[3, Gen3], Mf2[3, Gen3]])/(4*CW2*Pi) + 
   (3*Alfa*(-4/3 + SW2^(-1) + (8*SW2)/9)*B0i[bb00, MZ2, Mf2[4, Gen3], 
      Mf2[4, Gen3]])/(4*CW2*Pi) - (Alfa*MZ2*(-4 + SW2^(-1) + 8*SW2)*
     B0i[bb1, MZ2, Mf2[2, Gen3], Mf2[2, Gen3]])/(8*CW2*Pi) - 
   (3*Alfa*MZ2*(-8/3 + SW2^(-1) + (32*SW2)/9)*B0i[bb1, MZ2, Mf2[3, Gen3], 
      Mf2[3, Gen3]])/(8*CW2*Pi) - (3*Alfa*MZ2*(-4/3 + SW2^(-1) + (8*SW2)/9)*
     B0i[bb1, MZ2, Mf2[4, Gen3], Mf2[4, Gen3]])/(8*CW2*Pi) - 
   (Alfa*B0i[bb0, MZ2, Mf2[2, Gen3], Mf2[2, Gen3]]*Mf2[2, Gen3])/
    (8*CW2*Pi*SW2) - (3*Alfa*B0i[bb0, MZ2, Mf2[3, Gen3], Mf2[3, Gen3]]*
     Mf2[3, Gen3])/(8*CW2*Pi*SW2) - 
   (3*Alfa*B0i[bb0, MZ2, Mf2[4, Gen3], Mf2[4, Gen3]]*Mf2[4, Gen3])/
    (8*CW2*Pi*SW2))*SumOver[Gen3, 3]
