Alfa/(6*Pi) + (5*Alfa*B0i[bb0, 0, MW2, MW2])/(4*Pi) + 
 (Alfa*B0i[bb1, 0, MW2, MW2])/(2*Pi) + (3*Alfa*B0i[dbb00, 0, MW2, MW2])/Pi
