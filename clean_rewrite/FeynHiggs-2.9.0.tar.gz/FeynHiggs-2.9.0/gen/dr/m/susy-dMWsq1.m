-(Alfa*MW2*(-1 + SW2^(-1) - CW2/SW2))/(2*Pi) - 
 (Alfa*MW2*(1 + CW2/SW2))/(6*Pi) + (Alfa*(A0[MA02] + A0[Mh02] + A0[MHH2]))/
  (16*Pi*SW2) + (Alfa*A0[MHp2])/(8*Pi*SW2) + 
 (7*Alfa*(-4/7 + SW2^(-1) - (4*CW2)/(7*SW2))*A0[MW2])/(8*Pi) + 
 (Alfa*(1 + 12*CW2)*A0[MZ2])/(16*Pi*SW2) - (Alfa*MW2*B0i[bb0, MW2, 0, MW2])/
  (2*Pi) + (Alfa*MW2*SBA2*B0i[bb0, MW2, Mh02, MW2])/(4*Pi*SW2) + 
 (Alfa*CBA2*MW2*B0i[bb0, MW2, MHH2, MW2])/(4*Pi*SW2) + 
 ((-3*Alfa*CW2*MW2)/(4*Pi*SW2) + (Alfa*((-2*CW2*MZ2)/SW2 + (MW2*SW2)/CW2))/
    (4*Pi))*B0i[bb0, MW2, MW2, MZ2] - 
 (Alfa*SBA2*(B0i[bb00, MW2, Mh02, MW2] + B0i[bb00, MW2, MHH2, MHp2]))/
  (4*Pi*SW2) - (Alfa*CBA2*(B0i[bb00, MW2, Mh02, MHp2] + 
    B0i[bb00, MW2, MHH2, MW2]))/(4*Pi*SW2) - (2*Alfa*B0i[bb00, MW2, MW2, 0])/
  Pi - (2*Alfa*CW2*B0i[bb00, MW2, MW2, MZ2])/(Pi*SW2) - 
 (Alfa*(B0i[bb00, MW2, MA02, MHp2] + B0i[bb00, MW2, MZ2, MW2]))/(4*Pi*SW2) + 
 (Alfa*MW2*B0i[bb1, MW2, MW2, 0])/(2*Pi) + 
 (Alfa*CW2*MW2*B0i[bb1, MW2, MW2, MZ2])/(2*Pi*SW2) + 
 (Alfa*A0[MSf2[1, 1, Gen3]]*SumOver[Gen3, 3])/(8*Pi*SW2) + 
 SumOver[Gen3, 3]*SumOver[Sfe3, 2]*
  ((Alfa*A0[MSf2[Sfe3, 2, Gen3]]*USf[Sfe3, 1, 2, Gen3]*
     USfC[Sfe3, 1, 2, Gen3])/(8*Pi*SW2) - 
   (Alfa*B0i[bb00, MW2, MSf2[1, 1, Gen3], MSf2[Sfe3, 2, Gen3]]*
     USf[Sfe3, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3])/(2*Pi*SW2) + 
   (3*Alfa*A0[MSf2[Sfe3, 3, Gen3]]*USf[Sfe3, 1, 3, Gen3]*
     USfC[Sfe3, 1, 3, Gen3])/(8*Pi*SW2) + 
   (3*Alfa*A0[MSf2[Sfe3, 4, Gen3]]*USf[Sfe3, 1, 4, Gen3]*
     USfC[Sfe3, 1, 4, Gen3])/(8*Pi*SW2)) - 
 (3*Alfa*B0i[bb00, MW2, MSf2[Sfe3, 3, Gen3], MSf2[Sfe4, 4, Gen3]]*
   SumOver[Gen3, 3]*SumOver[Sfe3, 2]*SumOver[Sfe4, 2]*USf[Sfe3, 1, 3, Gen3]*
   USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 4, Gen3])/
  (2*Pi*SW2) + SumOver[Cha3, 2]*SumOver[Neu3, 4]*
  (-(Alfa*A0[MCha2[Cha3]]*((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
         (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/Sqrt[2])*
        (UCha[Cha3, 1]*ZNeuC[Neu3, 2] + (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/
          Sqrt[2]) + (VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
         (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/Sqrt[2])*
        (VCha[Cha3, 1]*ZNeuC[Neu3, 2] - (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/
          Sqrt[2])))/(2*Pi*SW2) + 
   (Alfa*B0i[bb00, MW2, MCha2[Cha3], MNeu2[Neu3]]*
     ((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/Sqrt[2])*
       (UCha[Cha3, 1]*ZNeuC[Neu3, 2] + (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/
         Sqrt[2]) + (VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
        (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/Sqrt[2])*
       (VCha[Cha3, 1]*ZNeuC[Neu3, 2] - (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/
         Sqrt[2])))/(Pi*SW2) + 
   (Alfa*MW2*B0i[bb1, MW2, MCha2[Cha3], MNeu2[Neu3]]*
     ((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/Sqrt[2])*
       (UCha[Cha3, 1]*ZNeuC[Neu3, 2] + (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/
         Sqrt[2]) + (VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
        (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/Sqrt[2])*
       (VCha[Cha3, 1]*ZNeuC[Neu3, 2] - (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/
         Sqrt[2])))/(2*Pi*SW2) + B0i[bb0, MW2, MCha2[Cha3], MNeu2[Neu3]]*
    ((Alfa*MW2*((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
          (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/Sqrt[2])*
         (UCha[Cha3, 1]*ZNeuC[Neu3, 2] + (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/
           Sqrt[2]) + (VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
          (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/Sqrt[2])*
         (VCha[Cha3, 1]*ZNeuC[Neu3, 2] - (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/
           Sqrt[2])))/(2*Pi*SW2) - 
     (Alfa*MNeu2[Neu3]*((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
          (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/Sqrt[2])*
         (UCha[Cha3, 1]*ZNeuC[Neu3, 2] + (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/
           Sqrt[2]) + (VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
          (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/Sqrt[2])*
         (VCha[Cha3, 1]*ZNeuC[Neu3, 2] - (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/
           Sqrt[2])))/(2*Pi*SW2) + (Alfa*MCha[Cha3]*MNeu[Neu3]*
       ((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/
           Sqrt[2])*(VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
          (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/Sqrt[2]) + 
        (UCha[Cha3, 1]*ZNeuC[Neu3, 2] + (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/
           Sqrt[2])*(VCha[Cha3, 1]*ZNeuC[Neu3, 2] - 
          (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/Sqrt[2])))/(2*Pi*SW2)))
