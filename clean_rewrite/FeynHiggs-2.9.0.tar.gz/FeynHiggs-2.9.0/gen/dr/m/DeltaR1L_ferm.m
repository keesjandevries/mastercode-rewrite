-(Alfa*(-96*(2*MT2 + MZ2)*SW2^2*A0[MT2] + 
     MT2*(-9*MZ2 + 192*MT2*SW2^2 + 64*MZ2*SW2^2 + 27*MZ2*B0[MZ2, 0, 0] + 
       96*(2*MT2 + MZ2)*SW2^2*B0[MZ2, MT2, MT2])))/(216*MT2*MZ2*Pi*SW2^2) + 
 (Alfa*((6*(MW2*(2 - 8*SW2) + MZ2*(-4*CW2 + SW2))*A0[Mf2[2, Gen3]])/
     (MW2*MZ2) + (12*(3 - 8*SW2)*A0[Mf2[3, Gen3]])/MZ2 + 
    (6*(MW2*(6 - 8*SW2) + 3*MZ2*(-4*CW2 + SW2))*A0[Mf2[4, Gen3]])/(MW2*MZ2) + 
    (6*(CW2 - SW2)*B0[MW2, 0, Mf2[2, Gen3]]*(MW2 - Mf2[2, Gen3])*
      (2*MW2 + Mf2[2, Gen3]))/MW2^2 + (6*(CW2 - SW2)*B0[0, 0, Mf2[2, Gen3]]*
      Mf2[2, Gen3]*(2*MW2 + Mf2[2, Gen3]))/MW2^2 + 
    (6*B0[MZ2, Mf2[2, Gen3], Mf2[2, Gen3]]*(MZ2*(-1 + 4*SW2) + 
       (1 + 8*SW2)*Mf2[2, Gen3]))/MZ2 + 
    (6*B0[MZ2, Mf2[3, Gen3], Mf2[3, Gen3]]*(MZ2*(-3 + 8*SW2) + 
       (3 + 16*SW2)*Mf2[3, Gen3]))/MZ2 + 
    (6*B0[MZ2, Mf2[4, Gen3], Mf2[4, Gen3]]*(MZ2*(-3 + 4*SW2) + 
       (3 + 8*SW2)*Mf2[4, Gen3]))/MZ2 + 
    (-2*MW2*MZ2*(-7 + 8*CW2 + 8*SW2) + 3*(-4*MW2 + 4*CW2*MZ2 + 16*MW2*SW2 - 
        MZ2*SW2)*Mf2[2, Gen3] + (-36*MW2 + 36*CW2*MZ2 + 96*MW2*SW2 - 
        9*MZ2*SW2)*Mf2[3, Gen3] + 3*(12*CW2*MZ2 - 3*MZ2*SW2 + 
        4*MW2*(-3 + 4*SW2))*Mf2[4, Gen3])/(MW2*MZ2) - 
    (18*(CW2 - SW2)*B0[MW2, Mf2[3, Gen3], Mf2[4, Gen3]]*
      (-2*MW2^2 + Mf2[3, Gen3]^2 + Mf2[3, Gen3]*(MW2 - 2*Mf2[4, Gen3]) + 
       Mf2[4, Gen3]*(MW2 + Mf2[4, Gen3])))/MW2^2 + 
    (18*B0[0, Mf2[3, Gen3], Mf2[4, Gen3]]*((CW2 - SW2)*Mf2[3, Gen3]^2 + 
       (CW2 - SW2)*Mf2[4, Gen3]*(2*MW2 + Mf2[4, Gen3]) - 
       Mf2[3, Gen3]*(MW2*(2*CW2 + SW2) + 2*(CW2 - SW2)*Mf2[4, Gen3])))/MW2^2)*
   SumOver[Gen3, 3])/(144*Pi*SW2^2)
