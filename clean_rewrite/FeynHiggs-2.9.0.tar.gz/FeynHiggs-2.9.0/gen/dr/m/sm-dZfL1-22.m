Alfa/(8*Pi*SW2) + (Alfa*(-4 + SW2^(-1) + 4*SW2))/(16*CW2*Pi) + 
 (Alfa*B0i[bb1, 0, 0, MW2])/(4*Pi*SW2) + 
 (Alfa*(-4/CW2 + 1/(CW2*SW2) + (4*SW2)/CW2)*B0i[bb1, 0, 0, MZ2])/(8*Pi)
