(2*((Alfa*(SW^(-1) - 2*SW - (2*SW2)/SW)*A0[Mf2[2, Gen3]])/(4*CW*Pi) + 
   (Alfa*(SW^(-1) - (4*SW)/3 - (4*SW2)/(3*SW))*A0[Mf2[3, Gen3]])/(2*CW*Pi) + 
   (Alfa*(SW^(-1) - (2*SW)/3 - (2*SW2)/(3*SW))*A0[Mf2[4, Gen3]])/(4*CW*Pi) - 
   (Alfa*(SW^(-1) - 2*SW - (2*SW2)/SW)*B0i[bb00, 0, Mf2[2, Gen3], 
      Mf2[2, Gen3]])/(2*CW*Pi) - (Alfa*(SW^(-1) - (4*SW)/3 - (4*SW2)/(3*SW))*
     B0i[bb00, 0, Mf2[3, Gen3], Mf2[3, Gen3]])/(CW*Pi) - 
   (Alfa*(SW^(-1) - (2*SW)/3 - (2*SW2)/(3*SW))*B0i[bb00, 0, Mf2[4, Gen3], 
      Mf2[4, Gen3]])/(2*CW*Pi))*SumOver[Gen3, 3])/MZ2
