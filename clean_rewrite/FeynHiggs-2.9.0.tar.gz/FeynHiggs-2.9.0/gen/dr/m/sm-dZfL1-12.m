Alfa/(8*Pi*SW2) + Alfa/(16*CW2*Pi*SW2) + (Alfa*B0i[bb1, 0, 0, MW2])/
  (4*Pi*SW2) + (Alfa*B0i[bb1, 0, 0, MZ2])/(8*CW2*Pi*SW2)
