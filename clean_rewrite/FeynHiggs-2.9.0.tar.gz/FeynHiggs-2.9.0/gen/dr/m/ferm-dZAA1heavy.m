(4*Alfa*B0i[bb1, 0, MT2, MT2])/(3*Pi) - (8*Alfa*B0i[dbb00, 0, MT2, MT2])/
  (3*Pi)
