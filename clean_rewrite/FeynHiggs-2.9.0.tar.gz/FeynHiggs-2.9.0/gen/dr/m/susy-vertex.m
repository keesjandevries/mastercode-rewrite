-(MW2*SW2*(((-24*Alfa2)/(MW2*(-MW2 + MZ2)*SW2^2) - (8*Alfa2*Dminus4)/
       (MW2*(-MW2 + MZ2)*SW2^2) + (48*Alfa2)/(MW2^2*SW2) + 
      (16*Alfa2*Dminus4)/(MW2^2*SW2) - (24*(Alfa2 - 2*Alfa2*SW2))/
       (MW2*(-MW2 + MZ2)*SW2^2) - (8*Dminus4*(Alfa2 - 2*Alfa2*SW2))/
       (MW2*(-MW2 + MZ2)*SW2^2))*A0[MW2] + 
    ((-24*Alfa2)/(MW2^2*SW2^2) - (8*Alfa2*Dminus4)/(MW2^2*SW2^2) + 
      (24*Alfa2*MZ2)/(MW2^2*(-MW2 + MZ2)*SW2^2) + (8*Alfa2*Dminus4*MZ2)/
       (MW2^2*(-MW2 + MZ2)*SW2^2) - (4*Dminus4*(2/MW2 + 1/(CW2*MZ2))*
        (Alfa2 - 2*Alfa2*SW2))/(MW2*SW2^2) - 
      (4*(6/MW2 + 1/(CW2*MZ2))*(Alfa2 - 2*Alfa2*SW2))/(MW2*SW2^2) - 
      (Dminus4^2*(Alfa2 - 2*Alfa2*SW2))/(CW2*MW2*MZ2*SW2^2) + 
      (24*MZ2*(Alfa2 - 2*Alfa2*SW2))/(MW2^2*(-MW2 + MZ2)*SW2^2) + 
      (8*Dminus4*MZ2*(Alfa2 - 2*Alfa2*SW2))/(MW2^2*(-MW2 + MZ2)*SW2^2))*
     A0[MZ2] + SumOver[Neu5, 4]*SumOver[Sfe5, 2]*
     ((-2*Alfa2*A0[MSf2[1, 1, 1]]*MSf2[1, 1, 1]*USf[Sfe5, 1, 2, 1]*
        USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
        (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/(CW2*MW2*SW2^2*
        (-MNeu2[Neu5] + MSf2[1, 1, 1])*(-MSf2[1, 1, 1] + MSf2[Sfe5, 2, 1])) - 
      (2*Alfa2*A0[MSf2[Sfe5, 2, 1]]*MSf2[Sfe5, 2, 1]*
        ((MSf2[1, 1, 1] - MSf2[Sfe5, 2, 1])^(-1) + 
         (-MNeu2[Neu5] + MSf2[Sfe5, 2, 1])^(-1))*USf[Sfe5, 1, 2, 1]*
        USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
        (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/(CW2*MW2*SW2^2*
        (-MNeu2[Neu5] + MSf2[1, 1, 1])) - (2*Alfa2*A0[MSf2[1, 1, 2]]*
        MSf2[1, 1, 2]*USfC[Sfe5, 1, 2, 2]*(SW*ZNeu[Neu5, 1] - 
         CW*ZNeu[Neu5, 2])*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
         CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/
       (CB*CW2*MW*MW2*SW2^2*(-MNeu2[Neu5] + MSf2[1, 1, 2])*
        (-MSf2[1, 1, 2] + MSf2[Sfe5, 2, 2])) - 
      (2*Alfa2*A0[MSf2[Sfe5, 2, 2]]*MSf2[Sfe5, 2, 2]*
        ((MSf2[1, 1, 2] - MSf2[Sfe5, 2, 2])^(-1) + 
         (-MNeu2[Neu5] + MSf2[Sfe5, 2, 2])^(-1))*USfC[Sfe5, 1, 2, 2]*
        (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*
          ZNeuC[Neu5, 1] + CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/
       (CB*CW2*MW*MW2*SW2^2*(-MNeu2[Neu5] + MSf2[1, 1, 2])) + 
      A0[MNeu2[Neu5]]*((2*Alfa2*MNeu2[Neu5]*USf[Sfe5, 1, 2, 1]*
          USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
          (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/(CW2*MW2*SW2^2*
          (-MNeu2[Neu5] + MSf2[1, 1, 1])*(-MNeu2[Neu5] + MSf2[Sfe5, 2, 1])) + 
        (2*Alfa2*MNeu2[Neu5]*USfC[Sfe5, 1, 2, 2]*(SW*ZNeu[Neu5, 1] - 
           CW*ZNeu[Neu5, 2])*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/(CB*CW2*MW*MW2*SW2^2*
          (-MNeu2[Neu5] + MSf2[1, 1, 2])*(-MNeu2[Neu5] + MSf2[Sfe5, 2, 
            2])))) + SumOver[Cha5, 2]*SumOver[Neu5, 4]*SumOver[Sfe5, 2]*
     (A0[MSf2[Sfe5, 2, 1]]*((8*Alfa2*MCha[Cha5]*MNeu[Neu5]*
          ((MNeu2[Neu5] - MSf2[Sfe5, 2, 1])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 1])^(-1))*UChaC[Cha5, 1]*
          USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
           CW*ZNeu[Neu5, 2])*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - 
           (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/Sqrt[2]))/(CW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])) + (2*Alfa2*Dminus4*MCha[Cha5]*
          MNeu[Neu5]*((MNeu2[Neu5] - MSf2[Sfe5, 2, 1])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 1])^(-1))*UChaC[Cha5, 1]*
          USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
           CW*ZNeu[Neu5, 2])*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - 
           (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/Sqrt[2]))/(CW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])) - (4*Alfa2*MSf2[Sfe5, 2, 1]*
          ((MNeu2[Neu5] - MSf2[Sfe5, 2, 1])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 1])^(-1))*UChaC[Cha5, 1]*
          USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
           CW*ZNeu[Neu5, 2])*(UCha[Cha5, 1]*ZNeuC[Neu5, 2] + 
           (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/Sqrt[2]))/(CW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])) - (2*Alfa2*Dminus4*MSf2[Sfe5, 2, 1]*
          ((MNeu2[Neu5] - MSf2[Sfe5, 2, 1])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 1])^(-1))*UChaC[Cha5, 1]*
          USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
           CW*ZNeu[Neu5, 2])*(UCha[Cha5, 1]*ZNeuC[Neu5, 2] + 
           (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/Sqrt[2]))/(CW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5]))) + A0[MCha2[Cha5]]*
       ((-8*Alfa2*MCha[Cha5]*MNeu[Neu5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*
          USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
          (VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MCha2[Cha5] + MSf2[Sfe5, 2, 1])) - 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*UChaC[Cha5, 1]*
          USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
           CW*ZNeu[Neu5, 2])*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - 
           (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/Sqrt[2]))/(CW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])*(-MCha2[Cha5] + MSf2[Sfe5, 2, 1])) + 
        (4*Alfa2*MCha2[Cha5]*UCha[Cha5, 1]*USfC[Sfe5, 1, 2, 2]*
          (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
            Sqrt[2])*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/(CB*CW*MW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])*(-MCha2[Cha5] + MSf2[Sfe5, 2, 2])) + 
        (2*Alfa2*Dminus4*MCha2[Cha5]*UCha[Cha5, 1]*USfC[Sfe5, 1, 2, 2]*
          (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
            Sqrt[2])*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/(CB*CW*MW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])*(-MCha2[Cha5] + MSf2[Sfe5, 2, 2])) + 
        (4*Alfa2*MCha2[Cha5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*
          USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
          (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MCha2[Cha5] + MSf2[Sfe5, 2, 1])) + 
        (2*Alfa2*Dminus4*MCha2[Cha5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*
          USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
          (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MCha2[Cha5] + MSf2[Sfe5, 2, 1])) - 
        (8*Alfa2*MCha[Cha5]*MNeu[Neu5]*UCha[Cha5, 1]*USfC[Sfe5, 1, 2, 2]*
          (CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CB*CW*MW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MCha2[Cha5] + MSf2[Sfe5, 2, 2])) - 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*UCha[Cha5, 1]*
          USfC[Sfe5, 1, 2, 2]*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CB*CW*MW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MCha2[Cha5] + MSf2[Sfe5, 2, 2]))) + A0[MNeu2[Neu5]]*
       ((8*Alfa2*MCha[Cha5]*MNeu[Neu5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*
          USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
          (VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MNeu2[Neu5] + MSf2[Sfe5, 2, 1])) + 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*UChaC[Cha5, 1]*
          USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
           CW*ZNeu[Neu5, 2])*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - 
           (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/Sqrt[2]))/(CW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])*(-MNeu2[Neu5] + MSf2[Sfe5, 2, 1])) - 
        (4*Alfa2*MNeu2[Neu5]*UCha[Cha5, 1]*USfC[Sfe5, 1, 2, 2]*
          (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
            Sqrt[2])*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/(CB*CW*MW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])*(-MNeu2[Neu5] + MSf2[Sfe5, 2, 2])) - 
        (2*Alfa2*Dminus4*MNeu2[Neu5]*UCha[Cha5, 1]*USfC[Sfe5, 1, 2, 2]*
          (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
            Sqrt[2])*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/(CB*CW*MW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])*(-MNeu2[Neu5] + MSf2[Sfe5, 2, 2])) - 
        (4*Alfa2*MNeu2[Neu5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*
          USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
          (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MNeu2[Neu5] + MSf2[Sfe5, 2, 1])) - 
        (2*Alfa2*Dminus4*MNeu2[Neu5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*
          USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
          (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MNeu2[Neu5] + MSf2[Sfe5, 2, 1])) + 
        (8*Alfa2*MCha[Cha5]*MNeu[Neu5]*UCha[Cha5, 1]*USfC[Sfe5, 1, 2, 2]*
          (CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CB*CW*MW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MNeu2[Neu5] + MSf2[Sfe5, 2, 2])) + 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*UCha[Cha5, 1]*
          USfC[Sfe5, 1, 2, 2]*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CB*CW*MW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])*
          (-MNeu2[Neu5] + MSf2[Sfe5, 2, 2]))) + A0[MSf2[Sfe5, 2, 2]]*
       ((-4*Alfa2*MSf2[Sfe5, 2, 2]*((MNeu2[Neu5] - MSf2[Sfe5, 2, 2])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 2])^(-1))*UCha[Cha5, 1]*
          USfC[Sfe5, 1, 2, 2]*(UChaC[Cha5, 1]*ZNeu[Neu5, 2] + 
           (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/Sqrt[2])*
          (CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/(CB*CW*MW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])) - (2*Alfa2*Dminus4*MSf2[Sfe5, 2, 2]*
          ((MNeu2[Neu5] - MSf2[Sfe5, 2, 2])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 2])^(-1))*UCha[Cha5, 1]*
          USfC[Sfe5, 1, 2, 2]*(UChaC[Cha5, 1]*ZNeu[Neu5, 2] + 
           (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/Sqrt[2])*
          (CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2]))/(CB*CW*MW*MW2*SW2^2*
          (-MCha2[Cha5] + MNeu2[Neu5])) + (8*Alfa2*MCha[Cha5]*MNeu[Neu5]*
          ((MNeu2[Neu5] - MSf2[Sfe5, 2, 2])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 2])^(-1))*UCha[Cha5, 1]*
          USfC[Sfe5, 1, 2, 2]*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CB*CW*MW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) + 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*
          ((MNeu2[Neu5] - MSf2[Sfe5, 2, 2])^(-1) + 
           (-MCha2[Cha5] + MSf2[Sfe5, 2, 2])^(-1))*UCha[Cha5, 1]*
          USfC[Sfe5, 1, 2, 2]*(CB*MW*SW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 1] + 
           CB*CW*MW*USf[Sfe5, 1, 2, 2]*ZNeuC[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CB*CW*MW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])))) + 
    SumOver[Cha5, 2]*SumOver[Neu5, 4]*
     (A0[MSf2[1, 1, 1]]*((4*Alfa2*MSf2[1, 1, 1]*
          ((MNeu2[Neu5] - MSf2[1, 1, 1])^(-1) + 
           (-MCha2[Cha5] + MSf2[1, 1, 1])^(-1))*VCha[Cha5, 1]*
          (VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/
            Sqrt[2])*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) + 
        (2*Alfa2*Dminus4*MSf2[1, 1, 1]*((MNeu2[Neu5] - MSf2[1, 1, 1])^(-1) + 
           (-MCha2[Cha5] + MSf2[1, 1, 1])^(-1))*VCha[Cha5, 1]*
          (VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/
            Sqrt[2])*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) - 
        (8*Alfa2*MCha[Cha5]*MNeu[Neu5]*((MNeu2[Neu5] - MSf2[1, 1, 1])^(-1) + 
           (-MCha2[Cha5] + MSf2[1, 1, 1])^(-1))*VCha[Cha5, 1]*
          (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2])*
          (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) - 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*((MNeu2[Neu5] - MSf2[1, 1, 1])^
            (-1) + (-MCha2[Cha5] + MSf2[1, 1, 1])^(-1))*VCha[Cha5, 1]*
          (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2])*
          (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5]))) + 
      A0[MSf2[1, 1, 2]]*((-8*Alfa2*MCha[Cha5]*MNeu[Neu5]*
          ((MNeu2[Neu5] - MSf2[1, 1, 2])^(-1) + 
           (-MCha2[Cha5] + MSf2[1, 1, 2])^(-1))*VChaC[Cha5, 1]*
          (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
          (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) - 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*((MNeu2[Neu5] - MSf2[1, 1, 2])^
            (-1) + (-MCha2[Cha5] + MSf2[1, 1, 2])^(-1))*VChaC[Cha5, 1]*
          (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
          (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) + 
        (4*Alfa2*MSf2[1, 1, 2]*((MNeu2[Neu5] - MSf2[1, 1, 2])^(-1) + 
           (-MCha2[Cha5] + MSf2[1, 1, 2])^(-1))*VChaC[Cha5, 1]*
          (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) + 
        (2*Alfa2*Dminus4*MSf2[1, 1, 2]*((MNeu2[Neu5] - MSf2[1, 1, 2])^(-1) + 
           (-MCha2[Cha5] + MSf2[1, 1, 2])^(-1))*VChaC[Cha5, 1]*
          (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
          (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
            Sqrt[2]))/(CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5]))) + 
      A0[MCha2[Cha5]]*((8*Alfa2*MCha[Cha5]*MNeu[Neu5]*
          ((VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
               Sqrt[2]))/(-MCha2[Cha5] + MSf2[1, 1, 2]) + 
           (VCha[Cha5, 1]*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2])*
             (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
               Sqrt[2]))/(-MCha2[Cha5] + MSf2[1, 1, 1])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) + 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*
          ((VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
               Sqrt[2]))/(-MCha2[Cha5] + MSf2[1, 1, 2]) + 
           (VCha[Cha5, 1]*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2])*
             (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
               Sqrt[2]))/(-MCha2[Cha5] + MSf2[1, 1, 1])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) - 
        (4*Alfa2*MCha2[Cha5]*((VCha[Cha5, 1]*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - 
              (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/Sqrt[2])*(SW*ZNeuC[Neu5, 1] - 
              CW*ZNeuC[Neu5, 2]))/(-MCha2[Cha5] + MSf2[1, 1, 1]) + 
           (VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
               Sqrt[2]))/(-MCha2[Cha5] + MSf2[1, 1, 2])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) - 
        (2*Alfa2*Dminus4*MCha2[Cha5]*
          ((VCha[Cha5, 1]*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*
                ZNeu[Neu5, 4])/Sqrt[2])*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 
                2]))/(-MCha2[Cha5] + MSf2[1, 1, 1]) + 
           (VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
               Sqrt[2]))/(-MCha2[Cha5] + MSf2[1, 1, 2])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5]))) + 
      A0[MNeu2[Neu5]]*((-8*Alfa2*MCha[Cha5]*MNeu[Neu5]*
          ((VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
               Sqrt[2]))/(-MNeu2[Neu5] + MSf2[1, 1, 2]) + 
           (VCha[Cha5, 1]*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2])*
             (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
               Sqrt[2]))/(-MNeu2[Neu5] + MSf2[1, 1, 1])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) - 
        (2*Alfa2*Dminus4*MCha[Cha5]*MNeu[Neu5]*
          ((VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (UChaC[Cha5, 1]*ZNeu[Neu5, 2] + (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/
               Sqrt[2]))/(-MNeu2[Neu5] + MSf2[1, 1, 2]) + 
           (VCha[Cha5, 1]*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2])*
             (UCha[Cha5, 1]*ZNeuC[Neu5, 2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/
               Sqrt[2]))/(-MNeu2[Neu5] + MSf2[1, 1, 1])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) + 
        (4*Alfa2*MNeu2[Neu5]*((VCha[Cha5, 1]*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - 
              (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/Sqrt[2])*(SW*ZNeuC[Neu5, 1] - 
              CW*ZNeuC[Neu5, 2]))/(-MNeu2[Neu5] + MSf2[1, 1, 1]) + 
           (VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
               Sqrt[2]))/(-MNeu2[Neu5] + MSf2[1, 1, 2])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5])) + 
        (2*Alfa2*Dminus4*MNeu2[Neu5]*
          ((VCha[Cha5, 1]*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*
                ZNeu[Neu5, 4])/Sqrt[2])*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 
                2]))/(-MNeu2[Neu5] + MSf2[1, 1, 1]) + 
           (VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
             (VCha[Cha5, 1]*ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/
               Sqrt[2]))/(-MNeu2[Neu5] + MSf2[1, 1, 2])))/
         (CW*MW2*SW2^2*(-MCha2[Cha5] + MNeu2[Neu5]))))))/(8*Alfa*D*Pi)
