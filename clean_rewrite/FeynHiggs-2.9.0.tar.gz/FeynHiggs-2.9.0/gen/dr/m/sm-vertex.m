-(MW2*SW2*(((-24*Alfa2)/(MW2*(-MW2 + MZ2)*SW2^2) - (8*Alfa2*Dminus4)/
       (MW2*(-MW2 + MZ2)*SW2^2) + (48*Alfa2)/(MW2^2*SW2) + 
      (16*Alfa2*Dminus4)/(MW2^2*SW2) - (24*(Alfa2 - 2*Alfa2*SW2))/
       (MW2*(-MW2 + MZ2)*SW2^2) - (8*Dminus4*(Alfa2 - 2*Alfa2*SW2))/
       (MW2*(-MW2 + MZ2)*SW2^2))*A0[MW2] + 
    ((-24*Alfa2)/(MW2^2*SW2^2) - (8*Alfa2*Dminus4)/(MW2^2*SW2^2) + 
      (24*Alfa2*MZ2)/(MW2^2*(-MW2 + MZ2)*SW2^2) + (8*Alfa2*Dminus4*MZ2)/
       (MW2^2*(-MW2 + MZ2)*SW2^2) - (4*Dminus4*(2/MW2 + 1/(CW2*MZ2))*
        (Alfa2 - 2*Alfa2*SW2))/(MW2*SW2^2) - 
      (4*(6/MW2 + 1/(CW2*MZ2))*(Alfa2 - 2*Alfa2*SW2))/(MW2*SW2^2) - 
      (Dminus4^2*(Alfa2 - 2*Alfa2*SW2))/(CW2*MW2*MZ2*SW2^2) + 
      (24*MZ2*(Alfa2 - 2*Alfa2*SW2))/(MW2^2*(-MW2 + MZ2)*SW2^2) + 
      (8*Dminus4*MZ2*(Alfa2 - 2*Alfa2*SW2))/(MW2^2*(-MW2 + MZ2)*SW2^2))*
     A0[MZ2]))/(8*Alfa*D*Pi)
