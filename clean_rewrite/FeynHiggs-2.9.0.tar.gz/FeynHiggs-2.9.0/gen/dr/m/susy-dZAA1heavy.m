Alfa/(6*Pi) + (5*Alfa*B0i[bb0, 0, MW2, MW2])/(4*Pi) + 
 (Alfa*B0i[bb1, 0, MW2, MW2])/(2*Pi) + (Alfa*B0i[dbb00, 0, MHp2, MHp2])/Pi + 
 (3*Alfa*B0i[dbb00, 0, MW2, MW2])/Pi - 
 (-((Alfa*B0i[bb1, 0, MCha2[Cha3], MCha2[Cha3]])/Pi) + 
   (2*Alfa*B0i[dbb00, 0, MCha2[Cha3], MCha2[Cha3]])/Pi)*SumOver[Cha3, 2] - 
 (-((Alfa*B0i[dbb00, 0, MSf2[Sfe3, 2, Gen3], MSf2[Sfe3, 2, Gen3]])/Pi) - 
   (4*Alfa*B0i[dbb00, 0, MSf2[Sfe3, 3, Gen3], MSf2[Sfe3, 3, Gen3]])/(3*Pi) - 
   (Alfa*B0i[dbb00, 0, MSf2[Sfe3, 4, Gen3], MSf2[Sfe3, 4, Gen3]])/(3*Pi))*
  SumOver[Gen3, 3]*SumOver[Sfe3, 2]
