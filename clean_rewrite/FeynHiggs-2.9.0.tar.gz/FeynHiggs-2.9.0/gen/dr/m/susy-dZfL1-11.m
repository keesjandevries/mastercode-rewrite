Alfa/(8*Pi*SW2) + Alfa/(16*CW2*Pi*SW2) + (Alfa*B0i[bb1, 0, 0, MW2])/
  (4*Pi*SW2) + (Alfa*B0i[bb1, 0, 0, MZ2])/(8*CW2*Pi*SW2) + 
 (Alfa*B0i[bb1, 0, MCha2[Cha3], MSf2[Sfe3, 2, 1]]*SumOver[Cha3, 2]*
   SumOver[Sfe3, 2]*UCha[Cha3, 1]*UChaC[Cha3, 1]*USf[Sfe3, 1, 2, 1]*
   USfC[Sfe3, 1, 2, 1])/(4*Pi*SW2) + 
 (Alfa*B0i[bb1, 0, MNeu2[Neu3], MSf2[1, 1, 1]]*SumOver[Neu3, 4]*
   (SW*ZNeu[Neu3, 1] - CW*ZNeu[Neu3, 2])*(SW*ZNeuC[Neu3, 1] - 
    CW*ZNeuC[Neu3, 2]))/(8*CW2*Pi*SW2)
