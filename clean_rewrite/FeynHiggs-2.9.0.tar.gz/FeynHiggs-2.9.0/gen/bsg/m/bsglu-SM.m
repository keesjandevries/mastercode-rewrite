((I/4)*CKM[Gen4, 3]*CKMC[Gen4, 2]*Mat[O8[6]]*
  (-2*A0[MW2]*(2*(MB2 - MW2)*MW2 + Mf2[3, Gen4]*(-MB2 + MW2 + 
       Mf2[3, Gen4])) + 2*A0[Mf2[3, Gen4]]*(2*(MB2 - MW2)*MW2 + 
     Mf2[3, Gen4]*(-MB2 + MW2 + Mf2[3, Gen4])) - 
   (MW2 - Mf2[3, Gen4])*(-2*MB2*MW2 + 
     MB2*(-1 + 2*C0[MB2, 0, 0, MW2, Mf2[3, Gen4], Mf2[3, Gen4]]*
        (MB2 - 2*MW2 - Mf2[3, Gen4]))*Mf2[3, Gen4] - 
     2*B0[MB2, MW2, Mf2[3, Gen4]]*(2*(MB2 - MW2)*MW2 + 
       Mf2[3, Gen4]*(-MB2 + MW2 + Mf2[3, Gen4]))))*SumOver[Gen4, 3])/
 (MB2^2*CKM[3, 3]*CKMC[3, 2]*(MW2 - Mf2[3, Gen4]))
