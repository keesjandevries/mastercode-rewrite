((I/2)*Mat[O8[6]]*SumOver[All4, 6]*SumOver[Cha4, 2]*SumOver[Ind1, 3]*
  SumOver[Ind2, 3]*((MB*SB2*(A0[MASf2[All4, 3]] - A0[MCha2[Cha4]])*
     CKM[Ind2, 3]*CKMC[Ind1, 2]*MCha[Cha4]*Mf[bTR, 3]*UASf[All4, Ind2, 3]*
     UCha[Cha4, 2]*(Sqrt[2]*MW*SB*UASfC[All4, Ind1, 3]*VCha[Cha4, 1] - 
      Mf[3, Ind1]*UASfC[All4, 3 + Ind1, 3]*VCha[Cha4, 2]))/
    (MASf2[All4, 3] - MCha2[Cha4]) + 
   MB*SB2*B0[MB2, MASf2[All4, 3], MCha2[Cha4]]*CKM[Ind2, 3]*CKMC[Ind1, 2]*
    MCha[Cha4]*Mf[bTR, 3]*UASf[All4, Ind2, 3]*UCha[Cha4, 2]*
    (-(Sqrt[2]*MW*SB*UASfC[All4, Ind1, 3]*VCha[Cha4, 1]) + 
     Mf[3, Ind1]*UASfC[All4, 3 + Ind1, 3]*VCha[Cha4, 2]) - 
   (CB*CKM[Ind1, 3]*CKMC[Ind2, 2]*(MB2 - 2*A0[MASf2[All4, 3]] + 
      2*A0[MCha2[Cha4]] + 2*MB2*C0[MB2, 0, 0, MASf2[All4, 3], MCha2[Cha4], 
        MASf2[All4, 3]]*MASf2[All4, 3] + 2*B0[MB2, MASf2[All4, 3], 
        MCha2[Cha4]]*(MASf2[All4, 3] - MCha2[Cha4]))*
     (SB2*UASf[All4, Ind1, 3]*(2*MW2*SB*UASfC[All4, Ind2, 3]*VCha[Cha4, 1] - 
        Sqrt[2]*MW*Mf[3, Ind2]*UASfC[All4, 3 + Ind2, 3]*VCha[Cha4, 2])*
       VChaC[Cha4, 1] + Mf[3, Ind1]*UASf[All4, 3 + Ind1, 3]*
       (-(Sqrt[2]*MW*SB2*UASfC[All4, Ind2, 3]*VCha[Cha4, 1]) + 
        SB*Mf[3, Ind2]*UASfC[All4, 3 + Ind2, 3]*VCha[Cha4, 2])*
       VChaC[Cha4, 2]))/2))/(CB*MB2^2*SB*SB2*CKM[3, 3]*CKMC[3, 2])
