(((2*I)/9)*Sqrt[2]*asMW*Pi*SumOver[All4, 6]*
  (Mat[O7[6]]*((MGl2 - MASf2[All4, bTR])*(MB2 + 2*A0[MGl2] - 
       2*A0[MASf2[All4, bTR]] + 2*MB2*C0[MB2, 0, 0, MGl2, MASf2[All4, bTR], 
         MASf2[All4, bTR]]*MASf2[All4, bTR] + 
       2*B0[MB2, MGl2, MASf2[All4, bTR]]*(-MGl2 + MASf2[All4, bTR]))*
      UASf[All4, 3, bTR] + 2*MB*Mino3*(-A0[MGl2] + A0[MASf2[All4, bTR]] + 
       B0[MB2, MGl2, MASf2[All4, bTR]]*(MGl2 - MASf2[All4, bTR]))*
      UASf[All4, 6, bTR])*UASfC[All4, 2, bTR] + 
   Mat[O7[7]]*(2*MB*Mino3C*(-A0[MGl2] + A0[MASf2[All4, bTR]] + 
       B0[MB2, MGl2, MASf2[All4, bTR]]*(MGl2 - MASf2[All4, bTR]))*
      UASf[All4, 3, bTR] + (MGl2 - MASf2[All4, bTR])*
      (MB2 + 2*A0[MGl2] - 2*A0[MASf2[All4, bTR]] + 
       2*MB2*C0[MB2, 0, 0, MGl2, MASf2[All4, bTR], MASf2[All4, bTR]]*
        MASf2[All4, bTR] + 2*B0[MB2, MGl2, MASf2[All4, bTR]]*
        (-MGl2 + MASf2[All4, bTR]))*UASf[All4, 6, bTR])*UASfC[All4, 5, bTR]))/
 (GF*MB2^2*CKM[3, 3]*CKMC[3, 2]*(MGl2 - MASf2[All4, bTR]))
